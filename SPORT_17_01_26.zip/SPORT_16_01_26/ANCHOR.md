# Anchor Snapshot

- Timestamp: {{ANCHOR_TIMESTAMP}}
- Backend: c:\Users\anyth\Documents\trae_projects\appp\server.js
  - PUBLIC_MODE flag: [server.js:L32](file:///c:/Users/anyth/Documents/trae_projects/appp/server.js#L32)
  - Racing upcoming region sanitization and retries: [server.js:L331-L366](file:///c:/Users/anyth/Documents/trae_projects/appp/server.js#L331-L366)
  - Brain verify endpoint: [server.js](file:///c:/Users/anyth/Documents/trae_projects/appp/server.js)
- Frontend: c:\Users\anyth\Documents\trae_projects\appp\public\index.html
  - Odds normalization and combo slip logic present
  - Floating notepad and slip transfer links enabled
- Boot scripts:
  - One-click: c:\Users\anyth\Documents\trae_projects\appp\one_click_boot.bat
  - One-click PS: c:\Users\anyth\Documents\trae_projects\appp\one_click_boot.ps1

This anchor marks the current working configuration for quick reference and rollback.
